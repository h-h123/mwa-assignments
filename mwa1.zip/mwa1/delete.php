<?php 
session_start(); 
include "db_conn.php";

if (isset($_SESSION['username'])) {

	if (isset($_POST['idd']) ) {

		function validate($data){
    		$data = trim($data);
	  	 	$data = stripslashes($data);
	  	 	$data = htmlspecialchars($data);
	  	 	return $data;
		}

		$idd = validate($_POST['idd']);

		
        $idd = intval($idd);
        $sql = "DELETE FROM `parking` WHERE id = $idd ";
        mysqli_query($conn, $sql);
		
		header("Location: mypost.php");
		
	
	}else{
		header("Location: mypost.php");
		exit();
	}


}else{
     header("Location: index.php?error=Please Login");
     exit();
}
?>