<?php
session_start(); 
include "db_conn.php";

if (isset($_SESSION['username'])) {

	$hii = $_SESSION['username'];

?>	
	
	<!DOCTYPE html>
	<html>
	<head>
    <title>My Post</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>
	<body>

    
	<a href="logout.php">Logout</a>
	<a href="addpost.php">AddPost</a>
	<a href="home.php">Home</a>
	
	<br><br>
	<?php if (isset($_GET['error'])) { ?>
     	<p class="error"><?php echo $_GET['error']; ?></p>
    <?php } ?>
	<?php if (isset($_GET['success'])) { ?>
     	<p class="success"><?php echo $_GET['success']; ?></p>
     <?php } ?>
     <br><br><br><br><br><br>

	 <?php

	 $sql = "SELECT * FROM `parking` WHERE username = '$hii' ORDER BY id DESC";
	 $result = mysqli_query($conn, $sql);
	 $row_number = mysqli_num_rows($result);
	 while($row = mysqli_fetch_assoc($result)) {
        ?>

        <div>

        <?php echo $row['username']; ?>
		.
		<?php echo $row['datee']; ?>

		<form  class= "form1" action="delete.php" method="post">
	     	
		<input type="hidden" name="idd" value="<?php echo $row['id']; ?>">

		<button type="delete" >delete</button>
    </form>
	<hr>
	<br>
        <?php echo $row['mpost']; ?> <br>

        </div>
        
		<br><br>
	<?php
		 
	 }
	 ?>

	</body>
	</html>
		
	
<?php
}else{
     header("Location: index.php");
     exit();
}
?>


