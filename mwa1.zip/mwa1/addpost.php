<?php 
session_start();
include "db_conn.php";

if (isset($_SESSION['username'])) {

?>

	<!DOCTYPE html>
	<html>
	<head>
		<title>Add Post</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>
	<body>
	
   
	<a href="logout.php">Logout</a>
	<a href="mypost.php">MyPost</a>
	<a href="home.php">Home</a>
	<br><br><br><br>
    	<form action="apost.php" method="post">
			<h2>Post</h2>
			<center><textarea name="ppost" style="width:65%;" rows="13" cols="50"></textarea></center>
			<br>			
			<center><button type="submit" style="width:15%;"><b>Post</b></button></center>
    	</form>
	 
	 
	</body>
	</html>

<?php
}else{
	header("Location: index.php?error=Please Login");
	exit();
}
?>