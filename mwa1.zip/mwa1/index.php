<?php 
session_start(); 
include "db_conn.php";

if (isset($_SESSION['username'])) {
    
    header("Location: home.php");
    exit();

    
}else{

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" type="image/png" href=""favicon.png>
</head>
<body>
	
	<?php if (isset($_GET['qr'])) { $qr = $_GET['qr']?>
		<form action="login.php?qr=<?php echo $qr?>" method="post">
	<?php }else{ ?>
		<form action="login.php" method="post">
	<?php } ?>
     
	 <h2>LOGIN</h2>
     	
	<?php if (isset($_GET['error'])) { ?>
     	<p class="error"><?php echo $_GET['error']; ?></p>
    <?php } ?>
	<?php if (isset($_GET['success'])) { ?>
     	<p class="success"><?php echo $_GET['success']; ?></p>
     <?php } ?>
     	
	<!--<label>User Name</label>-->
    <center><input type="text" name="uname" placeholder="Username"></center> <br>

    <!--<label>Password</label>-->
    <center><input type="password" name="password" placeholder="Password"></center> <br><br>

    <center><button type="submit" style="width:45%;"><b>Login</b></button></center>
    </form>
	
	<br><br><br><hr>
	<center>or</center>
	<br>

	<center><button style="width:30%; background :#00baff;" onclick=window.open("createaccount.php","_self"); ><b>Create Account</b></button></center>
</body>
</body>
</html>

<?php
}
?>