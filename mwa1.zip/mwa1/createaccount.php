<?php 
include "db_conn.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Create Account</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

    <form action="signup.php" method="post">
		<h2>Create Account</h2>
		<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
		
     	<!--<label>User Name</label>-->
     	<center><input type="text" name="uname" placeholder="Choose Username*"></center><br>

     	<!--<label>Email</label>-->
     	<center><input type="email" name="email" placeholder="Email*"></center><br>
		
		<!--<label>Password</label>-->
     	<center><input type="password" name="password" placeholder="Choose Password*"></center><br>
		
		<!--<label>CPassword</label>-->
		<center><input type="password" name="cpassword" placeholder="Confirm Password*"></center><br><br>

		<center><button type="submit" style="width:45%;"><b>Sign Up</b></button></center>
    </form>
	<br><br><br><hr>
	<center>or</center>
	<br>

	<center><button style="width:30%; background :#00baff;" onclick=window.open("index.php","_self"); ><b>Login</b></button></center>
	 
</body>
</html>