<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['uname']) && isset($_POST['email']) && isset($_POST['password'])&& isset($_POST['cpassword'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$uname = validate($_POST['uname']);
	$email = validate($_POST['email']);
	$pass = validate($_POST['password']);
	$cpass = validate($_POST['cpassword']);
	
	
	if (empty($uname)) {
		header("Location: createaccount.php?error=Please Choose Username");
	    exit();
	}else if(empty($email)){
        header("Location: createaccount.php?error=Please Enter Email");
	    exit();
	}else if(empty($pass)){
        header("Location: createaccount.php?error=Please Choose Password");
	    exit();
	}else if(empty($cpass)){
        header("Location: createaccount.php?error=Please Confirm Password");
	    exit();
	}else if($pass != $cpass){
        header("Location: createaccount.php?error=Password doesn't match");
	    exit();
	}else{
		$sql = "INSERT INTO users (username, email, password) VALUES ('$uname' , '$email','$pass');";
			mysqli_query($conn, $sql);
			
			header("Location: index.php?success= Account Created Successfully");
	}
	
}else{
	header("Location: createaccount.php");
	exit();
}
?>