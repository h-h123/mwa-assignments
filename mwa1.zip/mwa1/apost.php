<?php 
session_start(); 
include "db_conn.php";

if (isset($_SESSION['username'])) {

	if (isset($_POST['ppost']) ) {

		function validate($data){
    		$data = trim($data);
	  	 	$data = stripslashes($data);
	  	 	$data = htmlspecialchars($data);
	  	 	return $data;
		}

		$ppost = validate($_POST['ppost']);
		$lati = validate($_POST['lati']);
		$longi = validate($_POST['longi']);		

		$hii = $_SESSION['username'];

		$datee = date('y-m-d h:i:s');
	
	
		if(empty($ppost)){
        	header("Location: addpost.php?error=Please Enter ");
	    	exit();
		}else{
			$sql = "INSERT INTO parking (mpost, username, datee) VALUES ('$ppost' , '$hii' , '$datee');";
				mysqli_query($conn, $sql);
			
				header("Location: home.php");
		}
	
	}else{
		header("Location: home.php");
		exit();
	}


}else{
     header("Location: index.php?error=Please Login");
     exit();
}
?>