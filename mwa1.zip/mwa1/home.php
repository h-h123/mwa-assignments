<?php
session_start(); 
include "db_conn.php";

if (isset($_SESSION['username'])) {

	$hii = $_SESSION['username'];

?>	
	
	<!DOCTYPE html>
	<html>
	<head>
    <title>Home</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>
	<body>

    
	<a href="logout.php">Logout</a>
    <a href="mypost.php">MyPost</a>
	<a href="addpost.php">AddPost</a>
     <br><br><br><br><br><br>
	 <?php

	 $sql = "SELECT * FROM `parking` ORDER BY id DESC ";
	 $result = mysqli_query($conn, $sql);
	 $row_number = mysqli_num_rows($result);
	 while($row = mysqli_fetch_assoc($result)) {
        ?>

        <div>

        <?php echo $row['username']; ?>
		.
		<?php echo $row['datee']; ?><br><hr>
        <?php echo $row['mpost']; ?> <br>

        </div>
		<br><br>
	<?php
		 
	 }
	 ?>

	</body>
	</html>
		
	
<?php
}else{
     header("Location: index.php");
     exit();
}
?>


